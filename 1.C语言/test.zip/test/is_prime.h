/*************************************************************************
	> File Name: is_prime.h
	> Author: ldc
	> Mail: litesla
	> Created Time: 2018年10月07日 星期日 11时27分16秒
 ************************************************************************/

#ifndef _IS_PRIME_H
#define _IS_PRIME_H


int is_prime(int );

#endif
