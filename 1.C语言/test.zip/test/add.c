/*************************************************************************
	> File Name: add.c
	> Author: ldc
	> Mail: litesla
	> Created Time: 2018年10月07日 星期日 11时28分17秒
 ************************************************************************/

#include<stdio.h>
#include "test.h"

int add(int a,int b){
    return a + b;
}
